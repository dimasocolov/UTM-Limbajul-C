#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int a,b,c,i,key;
    float G;
    printf("Menu: \n");
    printf("1 - Metoda if \n");
    printf("2 - Metoda if-else \n");
    printf("3 - Metoda if-else-if \n");

    printf("\nIntrodu variabilele a, b, c, i: \n");
    scanf("%d%d%d%d", &a,&b,&c,&i);

    printf("Introdu metoda 1, 2 sau 3: \n");
    scanf("%d", &key);

    switch(key)
    {
    case 1:
        {
            if (i<4) {G=(c*a)/(i+pow(i,2));}
            if (4<=i<=6) {G=i+2*i+2;}
            if (i>6) {G=a*i+b+pow(i,3);}

            printf("G = %.2f", G);
            break;
        }
    case 2:
        {
            if (i<4) {G=(c*a)/(i+pow(i,2));}
            else {printf("Pentru i<4 nu sunt solutii \n");}

            if (4<=i<=6) {G=i+2*i+2;}
            else {printf("Pentru 4<=i<=6 nu sunt solutii \n");}

            if (i>6) {G=a*i+b+pow(i,3);}
            else {printf("Pentru i>6 nu sunt solutii \n");}

            printf("G = %.2f", G);
            break;
        }
    case 3:
        {
            if (i<4) {G=(c*a)/(i+b*i*i);}
                else
                {
                    if (i>6) {G=a*i+b*i*i*i;}
                    else {G=i+2*i+2;}
                }
            printf("G = %.2f", G);
        }
    default:{printf("Nu este asa metoda! Alege intre 1,2 si 3!");}
    }

getch();
}
