#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    printf("Scrie variabilele d si y \n");
    int d,y;
    float R;
    scanf("%d%d", &d,&y);

    R = (pow(sin(y),2)+0,3*d) / (pow(M_E,y)+log10(d));

    printf("R = %.2f", R);
    return 0;
}
