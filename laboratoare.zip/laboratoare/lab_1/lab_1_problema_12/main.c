#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    printf("Introdu variabilele t si x\n");
    int t,x;
    float K;
    scanf("%d%d", &t,&x);

    K = 7*pow(t,2) + 3*sin(pow(x,3)) + 9,2;

    printf("K = %.2f", K);
    return 0;
}
