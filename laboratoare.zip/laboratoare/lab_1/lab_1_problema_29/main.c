#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    printf("Scrie variabila y:\n");
    int y;
    float N;
    scanf("%d", &y);

    N = 3*pow(y,2) + sqrt(fabs(y+1));

    printf("N = %.2f", N);
    return 0;
}
