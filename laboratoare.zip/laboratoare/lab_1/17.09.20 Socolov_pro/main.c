#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    printf("Scrie variabilele a,b,c,x,y:\n");
    double sus1,sus2, jos1,jos2, stanga, ZZ;
    int a,b,c,x,y;
    double const e = 2.71;
    double const pi = 3.14;
    scanf("%d%d%d%d%d", &a,&b,&c,&x,&y);

    sus1 = pow(e,-pi+pow(x,2+a)+pow(y,3)+pow(c,2)) + sqrt( pow(x,2+a)+pow(y,2+b-((((pow(a,2)-b))) / (pow(c,2+cos(pow(a,2)))))) );

    sus2 = sqrt( (pow(x,-2*a+cos(pow(x,2))) + pow(b,2-pow(x,2+b))) / (pow(x,2) + 2*pow(y,2)) );

    jos1 = x-y+pow(c,2);

    jos2 = sqrt( (x+pow(y,a+cos(x-pow(y,2))+2)+tan(x)) / (2-pow(x,2+pow(cos(x),2))*pow(y,3)) );

    stanga = (a+b) / (pow(-x,2)+pow(b,y));

    ZZ = ( (sus1/sus2) / (jos1/jos2 + stanga) );

    printf("ZZ = %.2lf", &ZZ);
    return 0;
}
